# [e107 Bootstrap SkyApp](https://www.e107sk.com/)

[SkyApp](https://www.e107sk.com/) is based on SkyApp template created by Brad Traversy (https://github.com/bradtraversy/skyapp_bootstrap). It was used with his YTB course about sass long time ago.  


## Preview

[![SkyApp Preview](https://www.e107sk.com/media/img/800x0/2019-08/preview_responsive.png)](https://www.e107sk.com/demo/skyapp/)

**[View Live Preview](https://www.e107sk.com/demo/skyapp/)**

## Status

Released version 1.0.0

## Download and Installation

Standard e107 installation.
You can download theme from:
- e107.org (not always latest version)
- **[e107sk.com](https://www.e107sk.com/download/59/skyapp-e107-free-theme/)**
- github repository is working version in progress 

## Copyright and License

e107 stuff is released under GPL licence.
Startbootstrap stuff is released under MIT licence.

## Credits

Many thanks to Brad Traversy for awesome HTML template. Many thanks to e107 for great bootstrap CMS.


