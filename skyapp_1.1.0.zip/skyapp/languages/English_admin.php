<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - 
|

+----------------------------------------------------------------------------+
*/

define("LAN_THEMEPREF_00", "Branding:");
define("LAN_THEMEPREF_01", "Navbar Alignment:");
define("LAN_THEMEPREF_02", "Signup/Login Placement:");
define("LAN_THEMEPREF_03", "Bootswatch Styles:");
define("LAN_THEMEPREF_04", "Site Name");
define("LAN_THEMEPREF_05", "Logo");
define("LAN_THEMEPREF_06", "Logo &amp; Site Name");
define("LAN_THEMEPREF_07", "left");
define("LAN_THEMEPREF_08", "right");
define("LAN_THEMEPREF_09", "top");
define("LAN_THEMEPREF_10", "bottom");

if (!defined(("LAN_JM_ADMIN_HELP_01"))) { define("LAN_JM_ADMIN_HELP_01", "Help & Support"); } 
if (!defined(("LAN_JM_ADMIN_HELP_02"))) { define("LAN_JM_ADMIN_HELP_02", "The support forum for this plugin  is available on:  "); } 
if (!defined(("LAN_JM_ADMIN_HELP_03"))) { define("LAN_JM_ADMIN_HELP_03", "Support Forum"); } 
if (!defined(("LAN_JM_ADMIN_HELP_04"))) { define("LAN_JM_ADMIN_HELP_04", "There is documentation too. Something is missing or not clear? Create a question on the forum, we will add the answer asap.:   ");   } 
if (!defined(("LAN_JM_ADMIN_HELP_05"))) { define("LAN_JM_ADMIN_HELP_05", "Documentation");    } 
if (!defined(("LAN_JM_ADMIN_HELP_06"))) { define("LAN_JM_ADMIN_HELP_06", "Live preview:   ");   } 
if (!defined(("LAN_JM_ADMIN_HELP_07"))) { define("LAN_JM_ADMIN_HELP_07", "Demo");   } 
if (!defined(("LAN_JM_ADMIN_HELP_08"))) { define("LAN_JM_ADMIN_HELP_08", "Github repository:  ");  } 
if (!defined(("LAN_JM_ADMIN_HELP_09"))) { define("LAN_JM_ADMIN_HELP_09", "Github");  } 
if (!defined(("LAN_JM_ADMIN_HELP_10"))) { define("LAN_JM_ADMIN_HELP_10", "Download. Version on e107.org could be outdated. "); } 
if (!defined(("LAN_JM_ADMIN_HELP_11"))) { define("LAN_JM_ADMIN_HELP_11", "Download"); } 

?>
