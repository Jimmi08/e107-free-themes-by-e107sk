<?php 

$LAYOUT['blog'] = ' 	 	<section class="section-light top-inner">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					{SITESEARCH}
				</div>
				<div class="col-md-6">			
				</div>
			</div>
		</div>
	</section>
  
 {SETSTYLE=none}
	<section class="section-primary-a">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2>{THEME_PAGETITLE}{MENU=5}</h2>
				</div>
			</div>
		</div>
	</section>
	
	<section class="section-main">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
          {SETSTYLE=default}
          {---}
				</div>
				<div class="col-md-4">
          {SETSTYLE=menu}
          {MENU=1}
				</div>
			</div>
		</div>
	</section>
	{SETSTYLE=none}
	<section>
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="block block-light block-center"> {MENU=20}</div>
				</div>
				<div class="col-md-3">
					<div class="block block-light block-center">   {MENU=21}</div>
				</div>
				<div class="col-md-3">
					<div class="block block-light block-center">  {MENU=22}</div>
				</div>
				<div class="col-md-3">
					<div class="block block-light block-center">  {MENU=23}</div>
				</div>
			</div>
		</div>
	</section>';

