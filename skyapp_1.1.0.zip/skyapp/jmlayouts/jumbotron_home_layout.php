<?php

$LAYOUT['jumbotron_home'] =  '  <!-- Main jumbotron for a primary marketing message or call to action -->
	<section class="section-showcase">
		<div class="container showcase-content">
     {WMESSAGE=hide}
     {CMENU=welcome}
		</div>
	</section>

	<section class="section-light">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
          {SITESEARCH}
				</div>
				<div class="col-md-6">
				
				</div>
			</div>
		</div>
	</section>
	{SETSTYLE=none}
	<section>
		<div class="container">
			<div class="row">
				<div class="col-md-4">          
					<div class="block block-primary"> {MENU=10} </div>
				</div>
				<div class="col-md-4">          
					<div class="block block-secondary">{MENU=11} </div>
				</div>
				<div class="col-md-4"> 
					<div class="block block-primary"> {MENU=12}	</div>
				</div>
			</div>
		</div>
	</section>
	
	<section class="no-pad-top">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="block block-light block-center"> {MENU=20}</div>
				</div>
				<div class="col-md-3">
					<div class="block block-light block-center">   {MENU=21}</div>
				</div>
				<div class="col-md-3">
					<div class="block block-light block-center">  {MENU=22}</div>
				</div>
				<div class="col-md-3">
					<div class="block block-light block-center">  {MENU=23}</div>
				</div>
			</div>
		</div>
	</section>
	
	<section class="section-light extra-pad">
		<div class="container">
			<div class="row">
        {MENU=3}
			</div>
		</div>
	</section>
	{SETSTYLE=none}
	<section class="section-primary extra-pad">
		<div class="container">
			<div class="row"> {MENU=4}</div>
		</div>
	</section>
	
	{---}
	
	</div>';
 
