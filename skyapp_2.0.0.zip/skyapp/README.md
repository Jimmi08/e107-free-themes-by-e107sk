# [e107 Bootstrap SkyApp](https://www.e107sk.com/)

[SkyApp](https://www.e107sk.com/) is based on SkyApp template created by Brad Traversy (https://github.com/bradtraversy/skyapp_bootstrap). It was used with his YTB course about sass long time ago.  


## Preview

[![SkyApp Preview](https://www.e107sk.com/media/img/800x0/2021-01/skyapp_preview.png)](https://www.e107sk.com/demo/skyapp/)

**[View Live Preview](https://www.e107sk.com/demo/skyapp/)**

## Status

Released version 1.0.0

## Download and Installation

Standard e107 installation.

## Copyright and License

e107 stuff is released under GPL licence.

## Credits

Many thanks to Brad Traversy for awesome HTML template. Many thanks to e107 for great bootstrap CMS.


