<?php

if(!defined('e107_INIT'))
{
	exit();
}



class theme implements e_theme_render
{

	function __construct()
	{
		define("CORE_CSS", false);

		 
		 e107::css('theme', 'assets/css/main.css');
 

         $this->site_theme = e107::getPref('sitetheme');
		 
		 //this works only with custom tinymce plugin, not tinymce4 
         $this->theme_css_array = array(
			1 => e_THEME_ABS . $this->site_theme . '/assets/css/main.css',
			2 => e_THEME_ABS . $this->site_theme . '/wysiwyg.css',
		);

		if (e_PAGE == "login.php") {
			define('e_IFRAME', '0');
		}
 
	}

	function tablestyle($caption, $text, $mode='', $options = array())
	{

		$style = varset($options['setStyle'], 'default');

		// default style
		// only if this always work, play with different styles


		switch($style)
		{

			case "footer-small": 
				echo $text;
			break;

			case "nocaption": 
			case "none":
				echo $text;
			break;

			case "footer": 
				if(!empty($caption))
				{ 
					echo '<h4>' . $caption . '</h4>';
				}
				echo $text;
			break;

			case "menu": 
				echo '<div class="block block-primary-head no-pad">';
				if(!empty($caption))
				{ 
					echo '<h3>' . $caption . '</h3>';
				}
				echo '<div class="block-content">';
				echo $text;
				echo '</div></div>';
			break;
			
			case "main":   //for style with name main, mainly for frontpage
				if(!empty($caption))
				{
					echo '<div class="my-4">' . $caption . '</div>';
				}
				echo $text;
			break;

			case "default":   //for style with name default
				if(!empty($caption))
				{
					echo '<h2 class="page-header page-caption">' . $caption . '</h2>';
				}
				echo $text;
			break;			
		
			default:  //if there is no style

			if(!empty($caption))
			{
				echo '<div class="my-4">' . $caption . '</div>';
			}
			echo $text;
		}
		return;
	}

}
 