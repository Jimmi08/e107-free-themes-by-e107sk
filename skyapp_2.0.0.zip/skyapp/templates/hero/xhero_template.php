<?php

// Template File
// hero Template file

if (!defined('e107_INIT')) { exit; }

$HERO_TEMPLATE = array();
 
$string =  '<section class="py-0">{SETIMAGE: w=0&h=0}'.
''.
'<div class="bg-holder overlay overlay-3" style="background-image:url({HERO_IMAGE});" 
data-zanim-xs=\'{"delay":0,"ease":"Sine.easeInOut","duration":1,"from":{"scale":1.05,"alpha":1},"to":{"scale":1,"alpha":1}}\'>'.
'		  </div>'.
'		  <!--/.bg-holder-->'.
'		  <div class="container">'.
'			<div class="row flex-center min-vh-75">'.
'			  <div class="col-auto text-center">'.
'				<p class="font-italic p-0 mb-2 text-white fs-1 text-base" data-zanim-xs=\'{"delay":0.7,"duration":0.7,"ease":"Power2.easeOut","from":{"y":20,"opacity":0},"to":{"y":0,"opacity":1}}\'>{HERO_DESCRIPTION: enwrap=span&class=text-bold}</p>'.
'				<h2 class="text-uppercase text-white mb-md-5 mb-4 font-weight-extra-bold fs-3 fs-md-3 fs-lg-4 ls-1 pt-1" data-zanim-xs=\'{"delay":0,"duration":1,"ease":"Sine.easeInOut","from":{"letterSpacing":"0.25em","opacity":0},"to":{"letterSpacing":"0.05em","opacity":1}}\'>{HERO_TITLE: enwrap=strong}</h2>'.
'				<button class="btn btn-primary rounded-capsule mt-3 ls fs--1" data-zanim-xs=\'{"delay":1.2,"duration":0.7,"ease":"Power2.easeOut","from":{"y":-20,"opacity":0},"to":{"y":0,"opacity":1}}\'>{HERO_BUTTON1_LABEL}</button>'.
'			  </div>'.
'			</div><a class="text-white down-arrow" href="{HERO_BUTTON1_URL}" data-fancyscroll><span class="indicator-home-arrow" data-zanim-xs=\'{"ease":"Back.easeOut","delay":1.95,"duration":0.4,"from":{"y":0,"opacity":0},"to":{"y":16,"opacity":1}}\'></span><span class="indicator-home-arrow" data-zanim-xs=\'{"ease":"Back.easeOut","delay":2.2,"duration":0.4,"from":{"y":0,"opacity":0},"to":{"y":10,"opacity":1}}\'></span></a>'.
'		  </div>'.
'		  <!-- end of .container-->'.
''.
'		</section>';


$HERO_TEMPLATE['menu']['header'] 	= ' ';


$HERO_TEMPLATE['menu']['footer'] 	= '</ul>
  </div>';


$HERO_TEMPLATE['menu']['start'] 	    = ' <div class="flexslider text-center overflow-hidden mb-0 rounded-0">
        <ul class="slides"> ';

$HERO_TEMPLATE['menu']['item'] 	    = 


'<li class="text-center" data-zanim-timeline="{&quot;delay&quot;:0}">' .

'<section class="py-0">{SETIMAGE: w=0&h=0}'.
''.
'<div class="bg-holder overlay overlay-2" style="background-image:url({HERO_IMAGE});" 
data-zanim-xs=\'{"delay":0,"ease":"Sine.easeInOut","duration":1,"from":{"scale":1.05,"alpha":1},"to":{"scale":1,"alpha":1}}\'>'.
'		  </div>'.
'		  <!--/.bg-holder-->'.
'		  <div class="container">'.
'			<div class="row flex-center min-vh-75">'.
'			  <div class="col-auto text-center">'.
'				<p class="font-italic p-0 mb-2 text-white fs-1 text-base" data-zanim-xs=\'{"delay":0.7,"duration":0.7,"ease":"Power2.easeOut","from":{"y":20,"opacity":0},"to":{"y":0,"opacity":1}}\'>{HERO_DESCRIPTION: enwrap=span&class=text-bold}</p>'.
'				<h2 class="text-uppercase text-white mb-md-5 mb-4 font-weight-extra-bold fs-3 fs-md-3 fs-lg-4 ls-1 pt-1" data-zanim-xs=\'{"delay":0,"duration":1,"ease":"Sine.easeInOut","from":{"letterSpacing":"0.25em","opacity":0},"to":{"letterSpacing":"0.05em","opacity":1}}\'>{HERO_TITLE: enwrap=strong}</h2>'.
'				<button class="btn btn-primary rounded-capsule mt-3 ls fs--1" data-zanim-xs=\'{"delay":1.2,"duration":0.7,"ease":"Power2.easeOut","from":{"y":-20,"opacity":0},"to":{"y":0,"opacity":1}}\'>{HERO_BUTTON1_LABEL}</button>'.
'			  </div>'.
'			</div><a class="text-white down-arrow" href="{HERO_BUTTON1_URL}" data-fancyscroll><span class="indicator-home-arrow" data-zanim-xs=\'{"ease":"Back.easeOut","delay":1.95,"duration":0.4,"from":{"y":0,"opacity":0},"to":{"y":16,"opacity":1}}\'></span><span class="indicator-home-arrow" data-zanim-xs=\'{"ease":"Back.easeOut","delay":2.2,"duration":0.4,"from":{"y":0,"opacity":0},"to":{"y":10,"opacity":1}}\'></span></a>'.
'		  </div>'.
'		  <!-- end of .container-->'.
''.
'		</section>'.


'</li>';
 
$HERO_TEMPLATE['menu']['item'] = '{HERO_IMAGE}';








