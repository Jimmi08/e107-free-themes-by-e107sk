<?php

$MASTHEAD_TEMPLATE['default']['start'] = '';
$MASTHEAD_TEMPLATE['default']['item'] = '';
$MASTHEAD_TEMPLATE['default']['end'] = '';
 