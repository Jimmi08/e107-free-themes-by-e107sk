# MASTHEAD plugin

This plugin is attemp to replace missing functionality with core Welcome message. 

